import './App.css';
import SimpleStore from './SimpleStore'

function App() {
  return (
    <div className="App">
      <SimpleStore/>
    </div>
  );
}

export default App;
