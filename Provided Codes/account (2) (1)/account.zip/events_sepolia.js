const {ethers, JsonRpcProvider} = require('ethers');

const node = 'https://icy-virulent-diamond.matic-testnet.discover.quiknode.pro/31f37d091c1d4e85dc4c9d9cba66b1274a03d3c3/'; 

//const node = 'wss://20.58.166.39/8545';
const provider = new JsonRpcProvider(node);

const tokenAdress = '0xFEc3c047E688a002f1a6C2bd8531709A53550f73'; //shiba enu 0x95aD61b0a150d79219dCF64E1E6Cc01f0B64C4cE
//const tokenAddress = '0xa0b86991c6218b36c1d19d4a2e9eb0ce3606eb48'; //USDC
const tokenAbi = [
	{
		"inputs": [],
		"stateMutability": "nonpayable",
		"type": "constructor"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "address",
				"name": "owner",
				"type": "address"
			},
			{
				"components": [
					{
						"internalType": "uint256",
						"name": "age",
						"type": "uint256"
					},
					{
						"internalType": "string",
						"name": "name",
						"type": "string"
					}
				],
				"indexed": false,
				"internalType": "struct Events.Person",
				"name": "p2",
				"type": "tuple"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "timestamp",
				"type": "uint256"
			}
		],
		"name": "newPerson",
		"type": "event"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "_age",
				"type": "uint256"
			},
			{
				"internalType": "string",
				"name": "_name",
				"type": "string"
			}
		],
		"name": "setPerson",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"inputs": [],
		"name": "getPerson",
		"outputs": [
			{
				"components": [
					{
						"internalType": "uint256",
						"name": "age",
						"type": "uint256"
					},
					{
						"internalType": "string",
						"name": "name",
						"type": "string"
					}
				],
				"internalType": "struct Events.Person",
				"name": "",
				"type": "tuple"
			}
		],
		"stateMutability": "view",
		"type": "function"
	}
];
const contract = new ethers.Contract(tokenAdress, tokenAbi, provider);

async function main() {
    
    //const decimals = await contract.decimals();
   
    contract.on("newPerson",(from,to,data) => {
    
        console.log(from,to,data);
    
    })

    
    
    }

main();

